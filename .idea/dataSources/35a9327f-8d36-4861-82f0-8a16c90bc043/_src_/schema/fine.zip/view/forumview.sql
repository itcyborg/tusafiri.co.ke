create view forumview as
  select
    `fine`.`forums`.`Forum_ID`   AS `Forum_ID`,
    `fine`.`forums`.`PostDate`   AS `PostDate`,
    `fine`.`forums`.`Topic`      AS `Topic`,
    `fine`.`forums`.`ThreadBy`   AS `ThreadBy`,
    `fine`.`posts`.`PostBy`      AS `PostBy`,
    `fine`.`posts`.`PostContent` AS `PostContent`,
    `fine`.`posts`.`TimeStamp`   AS `TimeStamp`
  from (`fine`.`forums`
    join `fine`.`posts` on ((`fine`.`forums`.`Forum_ID` = `fine`.`posts`.`Forum_ID`)));
