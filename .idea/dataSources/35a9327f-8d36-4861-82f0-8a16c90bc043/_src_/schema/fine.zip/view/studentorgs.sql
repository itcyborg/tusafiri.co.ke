create view studentorgs as
  select
    `fine`.`organizations`.`name`            AS `name`,
    `fine`.`organizations`.`type`            AS `type`,
    `fine`.`organizations`.`target`          AS `target`,
    `fine`.`organizations`.`slogan`          AS `slogan`,
    `fine`.`organizations`.`description`     AS `description`,
    `fine`.`organizations`.`leader`          AS `leader`,
    `fine`.`organizations`.`time`            AS `time`,
    `fine`.`organizations`.`ID`              AS `ID`,
    `fine`.`student_leaders`.`adm_number`    AS `adm_number`,
    `fine`.`student_leaders`.`leader_name`   AS `leader_name`,
    `fine`.`student_leaders`.`year_of_study` AS `year_of_study`,
    `fine`.`student_leaders`.`leader_course` AS `leader_course`,
    `fine`.`student_leaders`.`leader_phone`  AS `leader_phone`,
    `fine`.`student_leaders`.`leader_email`  AS `leader_email`,
    `fine`.`student_leaders`.`resignation`   AS `resignation`,
    `fine`.`student_leaders`.`period`        AS `period`,
    `fine`.`student_leaders`.`Org_ID`        AS `Org_ID`
  from (`fine`.`organizations`
    left join `fine`.`student_leaders` on ((`fine`.`organizations`.`ID` = `fine`.`student_leaders`.`Org_ID`)));
