CREATE VIEW paidtrips AS
  SELECT
    `kiboit_tusafiri`.`payments`.`PID`          AS `PID`,
    `kiboit_tusafiri`.`payments`.`Invoice`      AS `Invoice`,
    `kiboit_tusafiri`.`payments`.`PayerID`      AS `PayerID`,
    `kiboit_tusafiri`.`payments`.`PStatus`      AS `PStatus`,
    `kiboit_tusafiri`.`payments`.`PaymentDate`  AS `PaymentDate`,
    `kiboit_tusafiri`.`payments`.`FirstName`    AS `FirstName`,
    `kiboit_tusafiri`.`payments`.`LastName`     AS `LastName`,
    `kiboit_tusafiri`.`payments`.`PayerEmail`   AS `PayerEmail`,
    `kiboit_tusafiri`.`payments`.`PaymentType`  AS `PaymentType`,
    `kiboit_tusafiri`.`payments`.`Currency`     AS `Currency`,
    `kiboit_tusafiri`.`payments`.`Amount`       AS `Amount`,
    `kiboit_tusafiri`.`payments`.`IPNTrackID`   AS `IPNTrackID`,
    `kiboit_tusafiri`.`payments`.`PaymentBy`    AS `PaymentBy`,
    `kiboit_tusafiri`.`payments`.`VerifySign`   AS `VerifySign`,
    `kiboit_tusafiri`.`payments`.`Item`         AS `Item`,
    `kiboit_tusafiri`.`payments`.`UQPID`        AS `UQPID`,
    `kiboit_tusafiri`.`joinedtrips`.`ID`        AS `ID`,
    `kiboit_tusafiri`.`joinedtrips`.`TripID`    AS `TripID`,
    `kiboit_tusafiri`.`joinedtrips`.`UQTID`     AS `UQTID`,
    `kiboit_tusafiri`.`joinedtrips`.`Email`     AS `Email`,
    `kiboit_tusafiri`.`joinedtrips`.`Contact`   AS `Contact`,
    `kiboit_tusafiri`.`joinedtrips`.`Name`      AS `Name`,
    `kiboit_tusafiri`.`joinedtrips`.`Gender`    AS `Gender`,
    `kiboit_tusafiri`.`joinedtrips`.`UQID`      AS `UQID`,
    `kiboit_tusafiri`.`joinedtrips`.`Timestamp` AS `Timestamp`
  FROM (`kiboit_tusafiri`.`joinedtrips`
    JOIN `kiboit_tusafiri`.`payments`
      ON ((`kiboit_tusafiri`.`joinedtrips`.`UQID` = `kiboit_tusafiri`.`payments`.`Invoice`)));
