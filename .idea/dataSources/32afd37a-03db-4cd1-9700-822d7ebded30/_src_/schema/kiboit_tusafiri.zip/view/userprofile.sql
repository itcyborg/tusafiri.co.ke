CREATE VIEW userprofile AS
  SELECT
    `kiboit_tusafiri`.`users`.`Email`        AS `Email`,
    `kiboit_tusafiri`.`users`.`Username`     AS `Username`,
    `kiboit_tusafiri`.`users`.`uniqueID`     AS `uniqueID`,
    `kiboit_tusafiri`.`users`.`FullName`     AS `FullName`,
    `kiboit_tusafiri`.`users`.`ProfPic`      AS `ProfPic`,
    `kiboit_tusafiri`.`users`.`Creation`     AS `Creation`,
    `kiboit_tusafiri`.`profile`.`ID`         AS `ID`,
    `kiboit_tusafiri`.`profile`.`UserID`     AS `UserID`,
    `kiboit_tusafiri`.`profile`.`City`       AS `City`,
    `kiboit_tusafiri`.`profile`.`Country`    AS `Country`,
    `kiboit_tusafiri`.`profile`.`PostalCode` AS `PostalCode`,
    `kiboit_tusafiri`.`profile`.`Address`    AS `Address`,
    `kiboit_tusafiri`.`profile`.`About`      AS `About`,
    `kiboit_tusafiri`.`profile`.`Contact`    AS `Contact`,
    `kiboit_tusafiri`.`profile`.`Twitter`    AS `Twitter`,
    `kiboit_tusafiri`.`profile`.`Facebook`   AS `Facebook`,
    `kiboit_tusafiri`.`profile`.`Company`    AS `Company`
  FROM (`kiboit_tusafiri`.`users`
    LEFT JOIN `kiboit_tusafiri`.`profile` ON ((convert(`kiboit_tusafiri`.`users`.`uniqueID` USING utf8) =
                                               convert(`kiboit_tusafiri`.`profile`.`UserID` USING utf8))));
