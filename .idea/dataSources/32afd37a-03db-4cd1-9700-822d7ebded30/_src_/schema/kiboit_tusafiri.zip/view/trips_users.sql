CREATE VIEW trips_users AS
  SELECT
    `kiboit_tusafiri`.`trips`.`ID`             AS `ID`,
    `kiboit_tusafiri`.`trips`.`UQID`           AS `UQID`,
    `kiboit_tusafiri`.`trips`.`Name`           AS `Name`,
    `kiboit_tusafiri`.`trips`.`Destination`    AS `Destination`,
    `kiboit_tusafiri`.`trips`.`Classification` AS `Classification`,
    `kiboit_tusafiri`.`trips`.`StartDate`      AS `StartDate`,
    `kiboit_tusafiri`.`trips`.`FinishDate`     AS `FinishDate`,
    `kiboit_tusafiri`.`trips`.`MeetingPoint`   AS `MeetingPoint`,
    `kiboit_tusafiri`.`trips`.`Slots`          AS `Slots`,
    `kiboit_tusafiri`.`trips`.`Photos`         AS `Photos`,
    `kiboit_tusafiri`.`trips`.`Info`           AS `Info`,
    `kiboit_tusafiri`.`trips`.`Amount`         AS `Amount`,
    `kiboit_tusafiri`.`trips`.`Per`            AS `Per`,
    `kiboit_tusafiri`.`trips`.`Welcome`        AS `Welcome`,
    `kiboit_tusafiri`.`trips`.`Timestamp`      AS `Timestamp`,
    `kiboit_tusafiri`.`trips`.`ByUser`         AS `ByUser`,
    `kiboit_tusafiri`.`trips`.`Post`           AS `Post`,
    `kiboit_tusafiri`.`trips`.`MeetingTime`    AS `MeetingTime`,
    `kiboit_tusafiri`.`trips`.`Deadline`       AS `Deadline`,
    `kiboit_tusafiri`.`trips`.`Status`         AS `Status`,
    `kiboit_tusafiri`.`users`.`Email`          AS `Email`,
    `kiboit_tusafiri`.`users`.`Role`           AS `Role`
  FROM (`kiboit_tusafiri`.`trips`
    LEFT JOIN `kiboit_tusafiri`.`users`
      ON ((`kiboit_tusafiri`.`users`.`uniqueID` = `kiboit_tusafiri`.`trips`.`ByUser`)));
