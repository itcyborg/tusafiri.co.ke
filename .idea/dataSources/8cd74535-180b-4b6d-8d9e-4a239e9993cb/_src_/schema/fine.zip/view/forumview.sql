CREATE VIEW forumview AS
  SELECT
    `fine`.`forums`.`Forum_ID`   AS `Forum_ID`,
    `fine`.`forums`.`PostDate`   AS `PostDate`,
    `fine`.`forums`.`Topic`      AS `Topic`,
    `fine`.`forums`.`ThreadBy`   AS `ThreadBy`,
    `fine`.`posts`.`PostBy`      AS `PostBy`,
    `fine`.`posts`.`PostContent` AS `PostContent`,
    `fine`.`posts`.`TimeStamp`   AS `TimeStamp`
  FROM (`fine`.`forums`
    JOIN `fine`.`posts` ON ((`fine`.`forums`.`Forum_ID` = `fine`.`posts`.`Forum_ID`)));
